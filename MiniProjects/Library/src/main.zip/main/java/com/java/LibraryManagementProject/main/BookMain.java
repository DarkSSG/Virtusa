package com.java.LibraryManagementProject.main;

import com.java.LibraryManagementProject.bal.BookBal;
import com.java.LibraryManagementProject.model.Book;

import java.util.List;
import java.util.Scanner;

public class BookMain {
  static Scanner sc = new Scanner(System.in);
  static BookBal bookBal = new BookBal();

  public static void showBookMain() {
    List<Book> bookList = bookBal.showBookBal();
    bookList.forEach(System.out::println);
  }

  public static void searchBookMain() {
    System.out.println("Enter Book ID: ");
    int bookID = sc.nextInt();
    Book book = bookBal.searchBookBal(bookID);
    if (book == null) {
      System.out.println("Book Not Found for BookID: " +bookID +".");
    }
    else {
      System.out.println(book);
    }
  }

  public static void addBookMain() {
    Book book = new Book();

    System.out.println("Enter BookID: ");
    book.setBookId(sc.nextInt());
    sc.nextLine();

    System.out.println("Enter Book Title: ");
    book.setTitle(sc.nextLine());

    System.out.println("Enter Book Author: ");
    book.setAuthor(sc.nextLine());

    System.out.println("Enter Book Category: ");
    book.setCategory(sc.nextLine());

    System.out.println("Enter Total Copies: ");
    book.setTotalCopies(sc.nextInt());

    System.out.println("Enter Issued Copies: ");
    book.setIssuedCopies(sc.nextInt());

    System.out.println(bookBal.addBookBal(book));
  }

  public static void updateBookMain() {
    Book book = new Book();

    System.out.println("Enter BookID: ");
    book.setBookId(sc.nextInt());
    sc.nextLine();

    System.out.println("Enter Book Title: ");
    book.setTitle(sc.nextLine());

    System.out.println("Enter Book Author: ");
    book.setAuthor(sc.nextLine());

    System.out.println("Enter Book Category: ");
    book.setCategory(sc.nextLine());

    System.out.println("Enter Total Copies: ");
    book.setTotalCopies(sc.nextInt());

    System.out.println("Enter Issued Copies: ");
    book.setIssuedCopies(sc.nextInt());

    System.out.println(bookBal.updateBookBal(book));
  }

  public static void issueBookMain() {
    int bookID;
    System.out.println("Enter BookID: ");
    bookID = sc.nextInt();
    System.out.println(bookBal.issueBookBal(bookID));
  }

  public static void deleteBookMain() {
    int bookID;
    System.out.println("Enter BookID: ");
    bookID = sc.nextInt();
    System.out.println(bookBal.deleteBookBal(bookID));
  }

  public static void returnBookMain() {
    int bookID;
    System.out.println("Enter BookID: ");
    bookID = sc.nextInt();
    System.out.println(bookBal.returnBookBal(bookID));
  }

  public static void main(String[] args) {
    int choice;

    do {
      System.out.println("OPTIONS FOR LIBRARY MANAGEMENT:- ");
      System.out.println("1. Add Book.");
      System.out.println("2. Show All Books.");
      System.out.println("3. Search Book.");
      System.out.println("4. Update Book.");
      System.out.println("5. Issue Book.");
      System.out.println("6. Return Book");
      System.out.println("7. Delete Book.");
      System.out.println("8. Exit. ");

      System.out.println("Enter Your Choice: ");
      choice = sc.nextInt();

      switch(choice) {
        case 1:
          addBookMain();
          break;
        case 2:
          showBookMain();
          break;
        case 3:
          searchBookMain();
          break;
        case 4:
          updateBookMain();
          break;
        case 5:
          issueBookMain();
          break;
        case 6:
          returnBookMain();
          break;
        case 7:
          deleteBookMain();
          break;
        case 8:
          System.exit(0);
        default:
          System.out.println("Invalid Choice!");
      }
    }while(true);
  }
}
